<section class="related-products-section">
    <div class="related-products-container">
        <header class="related-products-header">
            <h2 class="related-products-title">
                <?php print translate("Related Products"); ?>
            </h2>
        </header>
        
        <div class="related-products-content">
            <?php require("html/searchresults.php"); ?>
        </div>
    </div>
</section>